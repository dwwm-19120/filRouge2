<!--
    <script src="<?php echo base_url("assets/js/")."jquerry.js"?>"></script>
    <script src="<?php echo base_url("assets/js/")."jquerry.js"?>"></script>

-->
<script src="https://kit.fontawesome.com/1e7dc74d63.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" ></script>

<!--
<script src="<?php echo base_url("assets/js/")."jquerry.js"?>"></script>
-->
</body>
</html>