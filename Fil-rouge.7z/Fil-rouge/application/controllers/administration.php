<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Administration extends CI_Controller
{
  
}